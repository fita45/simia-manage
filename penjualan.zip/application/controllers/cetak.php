<?php
/**
 * Created by PhpStorm.
 * User: GilangSonar
 * Date: 12/19/13
 * Time: 5:36 AM
 */

class Cetak extends CI_Controller{
    function __construct(){
        parent::__construct();
        $this->load->model('model_app');
        $this->load->model('model_master');
        $this->load->helper('currency_format_helper');
    }

    function print_penjualan(){
        $id=$this->uri->segment(3);
        $data=array(
            'title'=>'Penjualan',
            'dt_contact'=>$this->model_master->getAllContact(),
            'dt_penjualan'=>$this->model_app->manualQuery("
                SELECT * from tbl_penjualan_header a
                left join tbl_pelanggan b
                on a.kd_pelanggan=b.kd_pelanggan
                left join tbl_pegawai c
                on a.kd_pegawai=c.kd_pegawai
                where a.kd_penjualan = '$id'
            ")->result(),
            'barang_jual'=>$this->model_app->manualQuery("
                select a.kd_barang,a.qty,b.nm_barang,b.harga from tbl_penjualan_detail a
                left join tbl_barang b on a.kd_barang=b.kd_barang
                where a.kd_penjualan = '$id'
            ")->result(),
        );
        $this->load->view('element/v_header',$data);
        $this->load->view('subelement/v_print_penjualan');
    }

}